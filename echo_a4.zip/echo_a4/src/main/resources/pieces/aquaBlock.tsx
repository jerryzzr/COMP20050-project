<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="aquaBlock" tilewidth="32" tileheight="32" tilecount="49" columns="7">
 <image source="../blocks/aquaBlock.svg" width="226" height="226"/>
</tileset>
