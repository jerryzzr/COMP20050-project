<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="orangeBlock" tilewidth="22" tileheight="22" tilecount="100" columns="10">
 <image source="../blocks/orangeBlock.svg" width="226" height="226"/>
</tileset>
