/**
 * echo
 * 20201034
 */
/**
 * @author agbod
 * Controller in MVC pattern
 */
package controller;