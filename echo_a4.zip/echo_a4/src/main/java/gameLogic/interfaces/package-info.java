/**
 * echo
 * 20201034
 */
/**
 * @author agbod
 *
 */
package gameLogic.interfaces;
