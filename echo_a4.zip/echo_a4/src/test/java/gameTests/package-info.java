/**
 * echo
 * 20201034
 */
/**
 * @author agbod
 * Game tests
 */
package gameTests;