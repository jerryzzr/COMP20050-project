/**
 * echo
 * 20201034
 */
/**
 * @author agbod
 * Game model tests
 */
package gameLogicTests;