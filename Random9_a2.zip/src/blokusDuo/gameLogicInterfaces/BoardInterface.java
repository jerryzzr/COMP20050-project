/**
 * Random9
 * 20201034
 */
package gameLogicInterfaces;

import java.util.List;

/**
 * @author agbod
 *
 */
public interface BoardInterface {
	
	final static int BOARD_SIZE = 14;
		
	char getSquareState(int row, int column); //Get character of a board square
		
	void updateBoard(MoveInterface move); //Update the board with a given move
	
	List<MoveInterface> validMoves(PlayerInterface player); //Return all a player's possible moves

	boolean hasValidMove(PlayerInterface player); //Return true if player has any possible moves, false otherwise
	
}
