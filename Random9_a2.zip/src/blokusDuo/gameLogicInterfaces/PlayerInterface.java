/**
 * Random9
 * 20201034
 */
package gameLogicInterfaces;

import java.util.List;

/**
 * @author agbod
 *
 */
public interface PlayerInterface {
	
	String getName();

	int getPlayerNumber();
	
	char getPlayerState();
	
	int getScore();
	
	List<PieceInterface> getPieces(); //Should return list of all available pieces
	
	void updateHistory(MoveInterface move); //Add a move to the players history
	
	int getMoveNum();
	
}
