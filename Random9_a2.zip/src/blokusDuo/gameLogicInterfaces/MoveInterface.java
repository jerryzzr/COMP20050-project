/**
 * Random9
 * 20201034
 */
package gameLogicInterfaces;

/**
 * @author agbod
 *
 */
public interface MoveInterface {
	
	PlayerInterface getPlayer(); //Return a player object

	PieceInterface getPiece(); //Return a player's piece

	int getRow(); //Return the selected row

	int getColumn(); //Return the selected column
	
}
