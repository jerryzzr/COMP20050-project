/**
 * Random9
 * 20201034
 */
package controller;

import java.util.ArrayList;

import gameLogic.*;
import gameLogicInterfaces.*;
import textIO.UI;

/**
 * @author agbod
 *
 */
public class Game {

	/**
	 * 
	 */
	static BoardInterface board = new Board(); //Initialise board
	static final char Player1Default = 'X';
	static final char Player2Default = 'O';
	static PlayerInterface player1;
	static PlayerInterface player2;

	public static void run(int startingPlayer) { //Run a full game from start to finish
		if (startingPlayer == 1) { //Initialise players
			player1 = new Player(UI.getName(Player1Default));
			player2 = new Player(UI.getName(Player2Default));
		} else {
			player2 = new Player(UI.getName(Player1Default));
			player1 = new Player(UI.getName(Player2Default));
		}

		UI.printFirstPlayer(player1);
		UI.printBoard(board);

		boolean player1HasMove = board.hasValidMove(player1);
		boolean player2HasMove = board.hasValidMove(player2);
		
		while (player1HasMove || player2HasMove) { //Play until neither player can make a move
			boolean completedMove;

			if (player1HasMove) {
				makeMove(player1);
			} else {
				UI.printNoValidMove(player1);
			}
			
			if (player2HasMove) {
				makeMove(player2);
			} else {
				UI.printNoValidMove(player2);
			}

		player1HasMove = board.hasValidMove(player1);
		player2HasMove = board.hasValidMove(player2);
		}
		
		UI.printResults(player1, player2);
	}
	
	private static MoveInterface getMove(PlayerInterface player) { //Get a regular move
		PieceInterface piece = new Piece(UI.getPiece(player));
		UI.printPiece(player, piece);
		UI.manipulatePiece(player, piece);
		int coordinates[] = UI.getCoordinates();
		MoveInterface move = new Move(player, piece, coordinates[0], coordinates[1]);
		// UI.printMove(move);
		return move;
	}

	private static void makeMove(PlayerInterface player) { //Get and make a move
		int invalidMoves = 0;
		boolean completedMove = false;

		while (!completedMove) {
			if (invalidMoves > 0) {
				UI.printInvalidMove();				
			}
			
			try {
				UI.printPieces(player1);
				UI.printPieces(player2);
				if (invalidMoves > 2) {
					UI.hint(board.validMoves(player));				
				}
				MoveInterface move = getMove(player);
				board.updateBoard(move);
				player.updateHistory(move);
				UI.printBoard(board);
				completedMove = true;
			} catch (InvalidMoveException e) {
				invalidMoves++;
			}
		}
	}

}
