/**
 * Random9
 * 20201034
 */
package controller;

import textIO.UI;

/**
 * @author agbod
 *
 */
public class Main {

	/**
	 * contains main function to start a game
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		UI.initScanner();
		Game.run(parseArgs(args));
		UI.closeScanner();
	}

	public static int parseArgs(String[] args) {
		for (String arg: args) {
			if (arg.equalsIgnoreCase("-x")) {
				return 1;
			}
			if (arg.equalsIgnoreCase("-o")) {
				return 2;
			}
		}
		return (int)(Math.random() * 2 + 1);
	}
}
