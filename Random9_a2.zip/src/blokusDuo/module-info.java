/**
 * 
 */
/**
 * @author agbod
 *
 */
module blokusDuo {
    // requires org.junit.jupiter.api;
    // requires org.junit.platform.runner;
}