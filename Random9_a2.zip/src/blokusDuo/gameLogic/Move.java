/**
 * Random9
 * 20201034
 */
package gameLogic;

import gameLogicInterfaces.*;

/**
 * @author agbod
 *
 */
public class Move implements MoveInterface {

	/**
	 * Helper class to represent abstract concept of a move and reduce length of method signatures
	 */
	private PlayerInterface player;
	
	private PieceInterface piece;
	
	private int row, column;
		
	public Move(PlayerInterface player, PieceInterface piece, int row, int column) {
		this.player = player;
		this.piece = new Piece(piece);
		this.row = row;
		this.column = column;
	}

	@Override
	public PlayerInterface getPlayer() {
		return player;
	}

	@Override
	public PieceInterface getPiece() {
		return piece;
	}

	@Override
	public int getRow() {
		return row;
	}

	@Override
	public int getColumn() {
		return column;
	}

}
