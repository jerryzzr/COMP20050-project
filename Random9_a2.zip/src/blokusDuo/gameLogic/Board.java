/**
 * Random9
 * 20201034
 */
package gameLogic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import gameLogicInterfaces.*;

/**
 * @author agbod
 *
 */
public class Board implements BoardInterface {

	/**
	 * Class to represent the physical object of the board as a 2D-array of squares/states
	 */	
	private class BoardSquare {
		static final char EmptyState = '.';
		static final char Player1StartingPoint = 'x';
		static final char Player2StartingPoint = 'o';

		private char state;

		BoardSquare() {
			this.state = EmptyState;
		}

		char getState() {
			return this.state;
		}

		void setState(char state) {
			this.state = state;
		}
	}

	private BoardSquare board[][] = new BoardSquare[BOARD_SIZE][BOARD_SIZE];
	
	public Board() { //Initialise board
		for (int i = 0; i < Board.BOARD_SIZE; i++) {
			for (int j = 0; j < Board.BOARD_SIZE; j++) {
				this.board[i][j] = new BoardSquare();
			}
		}
		this.board[4][4].setState(BoardSquare.Player1StartingPoint);
		this.board[9][9].setState(BoardSquare.Player2StartingPoint);
	}

	@Override
	public char getSquareState(int row, int column) {
		return this.board[row][column].getState();
	}
	
	@Override
	public void updateBoard(MoveInterface move) {
		if (isValidMove(move)) {
			int orientation[][] = move.getPiece().getOrientation();
			int pieceHeight = orientation.length;
			int pieceWidth = orientation[0].length;
			int referencePoint[] = getPieceReferencePoint(move.getPiece());
			int referenceRow = referencePoint[0];
			int referenceColumn = referencePoint[1];
			int row =  move.getRow();
			int column = move.getColumn();
			PlayerInterface player = move.getPlayer();
			for (int i = 0; i < pieceHeight; i++) {
				for (int j = 0; j < pieceWidth; j++) {
					if (orientation[i][j] >= 0) {
						int boardRow = (i - referenceRow) + row;
						int boardColumn = (j - referenceColumn) + column;
						this.board[boardRow][boardColumn].setState(player.getPlayerState());
					}
				}
			}
		} else {
			throw new InvalidMoveException("Invalid move. ");
		}
	}
	
	private boolean isWithinBoundaryCheck(MoveInterface move) { //Check that piece will be placed within board
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		boolean check = row - referenceRow >= 0 && row + (pieceHeight - (referenceRow + 1)) <= 13 && column - referenceColumn >= 0 && column + (pieceWidth - (referenceColumn + 1)) <= 13;
		return check;
	}
	
	private boolean noOccupiedSquareCheck(MoveInterface move) { //Check that piece will not overlap other pieces
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		boolean check = true;
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] >= 0) {
					int boardRow = (i - referenceRow) + row;
					int boardColumn = (j - referenceColumn) + column;
					if (this.board[boardRow][boardColumn].getState() != BoardSquare.EmptyState) {
						check = false;
						break;
					}
				}
			}
			if (!check) {
				break;
			}
		}
		return check;
	}

	private boolean noAdjacentSquareCheck(MoveInterface move) { //Check that that there will be no adjacent piece of the same colour
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		PlayerInterface player = move.getPlayer();
		boolean check = true;
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] >= 0) {
					int boardRow = (i - referenceRow) + row;
					int boardColumn = (j - referenceColumn) + column;
					if (boardRow - 1 >= 0 && this.board[boardRow - 1][boardColumn].getState() == player.getPlayerState()) {
						check = false;
						break;
					}
					if (boardRow + 1 <= 13 && this.board[boardRow + 1][boardColumn].getState() == player.getPlayerState()) {
						check = false;
						break;
					}
					if (boardColumn - 1 >= 0 && this.board[boardRow][boardColumn - 1].getState() == player.getPlayerState()) {
						check = false;
						break;
					}
					if (boardColumn + 1 <= 13 && this.board[boardRow][boardColumn + 1].getState() == player.getPlayerState()) {
						check = false;
						break;
					}
				}
			}
			if (!check) {
				break;
			}
		}
		return check;
	}

	private boolean isOnStartingSquare(MoveInterface move) {
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		int playerNumber = move.getPlayer().getPlayerNumber();
		boolean check = false;
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] >= 0) {
					int boardRow = (i - referenceRow) + row;
					int boardColumn = (j - referenceColumn) + column;
					if (playerNumber == 1 && this.board[boardRow][boardColumn].getState() == BoardSquare.Player1StartingPoint) {
						check = true;
					}
					if (playerNumber == 2 && this.board[boardRow][boardColumn].getState() == BoardSquare.Player2StartingPoint) {
						check = true;
					}
				}
			}
		}
		return check;
	}

	private boolean hasCornerSquareCheck(MoveInterface move) { //Check that piece will be touching the corner of another piece of the same colour
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		PlayerInterface player = move.getPlayer();
		boolean check = false;
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] >= 0) {
					int boardRow = (i - referenceRow) + row;
					int boardColumn = (j - referenceColumn) + column;
					if (boardRow - 1 >= 0 && boardColumn -1 >= 0 && this.board[boardRow - 1][boardColumn - 1].getState() == player.getPlayerState()) {
						check = true;
						break;
					}
					if (boardRow - 1 >= 0 && boardColumn + 1 <= 13 && this.board[boardRow - 1][boardColumn + 1].getState() == player.getPlayerState()) {
						check = true;
						break;
					}
					if (boardRow + 1 <= 13 && boardColumn - 1 >= 0 && this.board[boardRow + 1][boardColumn - 1].getState() == player.getPlayerState()) {
						check = true;
						break;
					}
					if (boardRow + 1 <= 13 && boardColumn + 1 <= 13 && this.board[boardRow + 1][boardColumn + 1].getState() == player.getPlayerState()) {
						check = true;
						break;
					}
				}
			}
			if (check) {
				break;
			}
		}
		return check;
	}

	private boolean isValidMove(MoveInterface move) { //Checks that all conditions are satisfied
		if (move.getPlayer().getMoveNum() == 0) { //Checks for first move when there is no other piece of the same colour on the board
			return isWithinBoundaryCheck(move) && isOnStartingSquare(move);
		} else {
			return isWithinBoundaryCheck(move) && noOccupiedSquareCheck(move) && noAdjacentSquareCheck(move) && hasCornerSquareCheck(move);
		}
	}

	private int[] getPieceReferencePoint(PieceInterface piece) { //Get the row and column of the reference point relative to the rest of the piece
		int orientation[][] = piece.getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = {-1, -1};
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] == piece.getReferencePoint()) {
					referencePoint[0] = i;
					referencePoint[1] = j;
					break;
				}
			}
			if (referencePoint[0] != -1 && referencePoint[1] != -1) {
				break;
			}
		}
		return referencePoint;
	}

	@Override
	public List<MoveInterface> validMoves(PlayerInterface player) {
		ArrayList<MoveInterface> availableMoves = new ArrayList<MoveInterface>();
		for (PieceInterface p: player.getPieces()) {
			PieceInterface piece = new Piece(p.getShape());
			for (int i = 0; i < 4; i++) {
				piece.rotate();
				for (int j = 0; j < 2; j++) {
					piece.flip();
					for (int k = 0; k < Board.BOARD_SIZE; k++) {
						for (int l = 0; l < Board.BOARD_SIZE; l++) {
							MoveInterface move = new Move(player, piece, k, l);
							if (isValidMove(move) && !containsMove(availableMoves, move)) {
								availableMoves.add(move);
							}
						}
					}
				}
			}
		}
		return availableMoves;
	}

	private boolean containsMove(List<MoveInterface> moves, MoveInterface move) {
		boolean present = false;
		for (MoveInterface m: moves) {
			PieceInterface p = m.getPiece();
			int r = m.getRow();
			int c = m.getColumn();
			if (Arrays.deepEquals(p.getOrientation(), move.getPiece().getOrientation()) && r == move.getRow() && c == move.getColumn()) {
				present = true;
				break;
			}
		}
		return present;
	}

	@Override
	public boolean hasValidMove(PlayerInterface player) {
		return !this.validMoves(player).isEmpty();
	}

}
