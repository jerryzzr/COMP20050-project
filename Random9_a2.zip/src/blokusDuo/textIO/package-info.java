/**
 * Random9
 * 20201034
 */
/**
 * @author agbod
 * View in MVC pattern
 */
package textIO;