/**
 * Random9
 * 20201034
 */
package textIO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import gameLogicInterfaces.*;

/**
 * @author agbod
 *
 */
public class UI {

	/**
	 * Utility class for console IO
	 */
	private static Scanner scanner;
	private static ArrayList<String> playerNames = new ArrayList<String>();
	
	public static void initScanner() {
		scanner = new Scanner(System.in);
	}
	
	public static void printFirstPlayer(PlayerInterface player) {
		System.out.println();		
		System.out.print("Player " + player.getName());
		System.out.println(" (" + player.getPlayerState() + ") goes first! ");
	}

	public static void printBoard(BoardInterface board) {
		System.out.println();		
		System.out.println("BLOKUS DUO");
		System.out.println();		
		for (int i = 0; i < BoardInterface.BOARD_SIZE; i++) {
			int row = BoardInterface.BOARD_SIZE - (i + 1);
			if (row < 10)
				System.out.print(" " + row + " ");
			else
				System.out.print(row + " ");
			for (int j = 0; j < BoardInterface.BOARD_SIZE; j++) {
				System.out.print(board.getSquareState(i, j) + " ");
			}
			System.out.println();
		}
		System.out.println("   0 1 2 3 4 5 6 7 8 9 10111213");
		System.out.println();
		System.out.println();
	}

	public static void printPiece(PlayerInterface player, PieceInterface piece) {
		System.out.println(piece.getShape() + ": ");
		int orientation[][] = piece.getOrientation();
		for (int i = 0; i < orientation.length; i++) {
			for (int j = 0; j < orientation[0].length; j++) {
				if (orientation[i][j] == piece.getReferencePoint()) {
					System.out.print("* ");
				} else if (orientation[i][j] >= 0) {
					System.out.print(player.getPlayerState() + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("\'*\' is the reference point of the piece. ");
		System.out.println();
	}
	
	private static void printPieceNumbers(PieceInterface piece) { //Print piece as numbers unique to block components of the piece
		System.out.println(piece.getShape() + ": ");
		int orientation[][] = piece.getOrientation();
		for (int i = 0; i < orientation.length; i++) {
			for (int j = 0; j < orientation[0].length; j++) {
				if (orientation[i][j] >= 0) {
					System.out.print(orientation[i][j] + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("The reference point of the piece is " + piece.getReferencePoint());
		System.out.println();
	}

	public static void printPieces(PlayerInterface player) {
		System.out.print("Player " + player.getName());
		System.out.print(" (" + player.getPlayerState() + ") gamepieces:");
		for (PieceInterface pieces: player.getPieces()) {
			System.out.print(" " + pieces.getShape());
		}
		System.out.println();
	}
	
	public static void printMove(MoveInterface move) {
		PlayerInterface player = move.getPlayer();
		System.out.print("Player " + player.getName());
		System.out.println(" (" + player.getPlayerState() + ") can place: ");
			printPiece(player, move.getPiece());
			System.out.println("on row " + ((BoardInterface.BOARD_SIZE - 1) - move.getRow()) + ", column " + move.getColumn());
			System.out.println();
	}

	public static void printMoves(PlayerInterface player, List<MoveInterface> moves) {
		System.out.print("Player " + player.getName());
		System.out.println(" (" + player.getPlayerState() + ") moves:");
		for (MoveInterface move: moves) {
			printPiece(player, move.getPiece());
			System.out.println("on row " + ((BoardInterface.BOARD_SIZE - 1) - move.getRow()) + ", column " + move.getColumn());
			System.out.println();
		}
	}

	public static void printInvalidMove() { //Notify player that move selected was invalid
		System.out.println("You have entered an invalid move. Try again. ");
		System.out.println();
	}

	public static void printNoValidMove(PlayerInterface player) { //Notify player that there are no valid moves
		System.out.println("Player " + player.getName() + " does not have any valid moves. ");
		System.out.println();
	}

	public static void printResults(PlayerInterface player1, PlayerInterface player2) {
		printPieces(player1);
		printPieces(player2);
		int player1Score = player1.getScore();
		int player2Score = player2.getScore();
		System.out.println();
		System.out.println("GAME OVER! ");
		System.out.println();
		if (player1Score > player2Score) {
			System.out.print(player1.getName() + " finished the game with " + player1Score + " points");
			System.out.println(" and " + player2.getName() + " finished the game with " + player2Score + " points. ");
			System.out.println(player1.getName() + " wins! ");
			System.out.println();
		} else if (player1Score < player2Score) {
			System.out.print(player1.getName() + " finished the game with " + player1Score + " points");
			System.out.println(" and " + player2.getName() + " finished the game with " + player2Score + " points. ");
			System.out.println(player2.getName() + " wins! ");
			System.out.println();
		} else {
			System.out.println("This game ended in a draw between " + player1.getName() + " and " + player2.getName() + ". ");
			System.out.println("Both players had " + player1Score + " points. ");
			System.out.println();
		}

	}

	public static void hint(List<MoveInterface> moves) {
		Iterator movesIterator = moves.iterator();
		System.out.println("Enter \'h\' for a hint or anything else to enter a move: ");
		String temp = scanner.next();
		while (temp.trim().equalsIgnoreCase("h") && movesIterator.hasNext()) {
			printMove((MoveInterface)movesIterator.next());
			if (movesIterator.hasNext()) {
				System.out.println("Enter \'h\' for another hint or anything else to enter a move: ");
				temp = scanner.next();
			} else {
				System.out.println("There are no more available moves. ");				
			}
		}
	}

	public static String getName(char playerChar) {
		System.out.print("Enter the name of Player " + playerChar + ": ");
		String playerName = scanner.nextLine();
		while (playerName.trim().isEmpty() || playerName == null || playerNames.contains(playerName)) {
			System.out.println("Player " + playerChar + "\'s name cannot be blank or the same as another player's name. ");
			System.out.print("Enter the name of Player " + playerChar + ": ");
			playerName = scanner.nextLine();
		}
		playerName = playerName.trim();
		playerNames.add(playerName);
		return playerName;
	}

	public static String getPiece(PlayerInterface player) { //Get piece a player wants to play
		System.out.println();
		System.out.print("Enter the piece you want to play: ");
		String pieceName = scanner.next().trim().toUpperCase();
		ArrayList<String> pieceNames = new ArrayList<String>();
		for (PieceInterface p: player.getPieces()) {
			pieceNames.add(p.getShape());
		}
		while (!pieceNames.contains(pieceName)) {
			System.out.print(pieceName + " is unavailable or not a valid piece. ");
			System.out.print("Enter the piece you want to play: ");
			pieceName = scanner.next().trim().toUpperCase();
		}
		return pieceName;
	}
	
	public static void changeReferencePoint(PieceInterface piece) { //Change the block on a piece that is referenced to place it on the board. Useful for first move
		printPieceNumbers(piece);
		System.out.print("Enter a number between 0 and " + (piece.getSize() - 1));
		System.out.println(" to change the reference point to that number. ");
		System.out.print("Enter anything else to keep it the same: ");
		int referencePoint = -1;
		try {
			referencePoint = scanner.nextInt();
			scanner.nextLine();
		} catch (NoSuchElementException e) {
			referencePoint = piece.getReferencePoint();
			scanner.nextLine();
		}
		if (referencePoint >= 0 && referencePoint <= piece.getSize() - 1 && referencePoint != piece.getReferencePoint()) {
			piece.setReferencePoint(referencePoint);
			System.out.println("The reference point is now " + referencePoint + ". ");
		} else {
			System.out.println("The reference point will remain as " + referencePoint + ". ");
		}
		System.out.println();
	}

	public static void manipulatePiece(PlayerInterface player, PieceInterface piece) { //Rotate the piece
		System.out.println("Enter \'r\' to rotate, \'f\' to flip or \'p\' to place the gamepiece: ");
		String temp = scanner.next();
		while (!temp.trim().equalsIgnoreCase("p")) {
			if (temp.trim().equalsIgnoreCase("r")) {
				piece.rotate();
				printPiece(player, piece);
			} else if (temp.trim().equalsIgnoreCase("f")) {
				piece.flip();
				printPiece(player, piece);
			}
			temp = scanner.next();
		}
		System.out.println();
	}
	
	public static int[] getCoordinates() {
		System.out.print("Enter x and y coordinates on the board: ");
		int row = -1;
		int column = -1;
		try {
			column = scanner.nextInt();
			row = scanner.nextInt();
		} catch (NoSuchElementException e) {
			row = -1;
			column = -1;
		}
		while (row < 0 || row > 13 || column < 0 || column  > 13) {
			try {
				System.out.print("x and y must be integers between 0 and 13: ");
				column = scanner.nextInt();
				row = scanner.nextInt();
			} catch (NoSuchElementException e) {
				row = -1;
				column = -1;
			}
		}
		int coordinates[] = new int[2];
		coordinates[0] = (BoardInterface.BOARD_SIZE - 1) - row;
		coordinates[1] = column;
		System.out.println();
		return coordinates;
	}

	public static int getRow() { //Get row to place a piece on
		System.out.print("Enter the row to place the piece: ");
		int row = -1;
		try {
			row = scanner.nextInt();
			scanner.nextLine();
		} catch (NoSuchElementException e) {
			row = -1;
		}
		while (row < 0 || row > 13) {
			try {
				System.out.print("Enter a number between 0 and 13: ");
				row = scanner.nextInt();
				scanner.nextLine();
			} catch (NoSuchElementException e) {
				row = -1;
			}
		}
		return (BoardInterface.BOARD_SIZE - 1) - row;
	}
	
	public static int getColumn() { //Get column to place a piece on
		System.out.print("Enter the column to place the piece: ");
		int column = -1;
		try {
			column = scanner.nextInt();
			scanner.nextLine();
		} catch (NoSuchElementException e) {
			column = -1;
		}
		while (column < 0 || column > 13) {
			try {
				System.out.print("Enter a number between 0 and 13: ");
				column = scanner.nextInt();
				scanner.nextLine();
			} catch (NoSuchElementException e) {
				column = -1;
			}
		}
		return column;
	}

	public static void closeScanner() {
		scanner.close();
	}

}
