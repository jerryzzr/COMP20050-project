/**
 * Random9
 * 20201034
 */
package tests;

import static org.junit.jupiter.api.Assertions.*;

import static java.time.Duration.ofMillis;

import org.junit.jupiter.api.*;

import java.io.*;

import java.util.ArrayList;
import java.util.Arrays;

import controller.Main;
import gameLogic.*;
import gameLogicInterfaces.*;
import textIO.UI;

class BlokusDuoTests {
	private ByteArrayInputStream byteArrayInputStream;
	private ByteArrayOutputStream byteArrayOutputStream;
	private static InputStream stdin;
	private static PrintStream stdout;
	private static PrintStream stderr;
	private PrintStream printStream;
	private FileInputStream fileInputStream;

	@BeforeAll
	public static void setUpAll() {
		stdin = System.in;
		stdout = System.out;
		stderr = System.err;
		System.setErr(stdout);
		// byteArrayInputStream = new ByteArrayInputStream();
		// byteArrayOutputStream = new ByteArrayOutputStream();
		// System.setIn(byteArrayInputStream);
		// System.setOut(new PrintStream(byteArrayOutputStream));
	}

	@BeforeEach
	public void setUpEach() {
		resetInput();
		resetOutput();
	}

	public void setInput(String s) {
		byteArrayInputStream = new ByteArrayInputStream(s.getBytes());
		initScanner(byteArrayInputStream);
	}

	public void resetInput() {
		byteArrayInputStream = new ByteArrayInputStream("".getBytes());
		initScanner(byteArrayInputStream);
	}

	public void setInputFromFile(String s) {
		try {
			fileInputStream = new FileInputStream(s);
			initScanner(fileInputStream);
		} catch (FileNotFoundException e) {
			System.out.println(e);
			resetInput();
		}
	}

	public void initScanner(InputStream stream) {
		System.setIn(stream);
		UI.initScanner();
	}

	public void resetOutput() {
		byteArrayOutputStream = new ByteArrayOutputStream();
		printStream = new PrintStream(byteArrayOutputStream);
		System.setOut(printStream);
	}

	@AfterAll
	public static void tearDownAll() {
		System.setIn(stdin);
		System.setOut(stdout);
		System.setErr(stderr);
	}

	@AfterEach
	public void tearDownEach() {
		UI.closeScanner();
		try {
			if (fileInputStream != null) {
				fileInputStream.close();
			}
		} catch (IOException e) {
			System.err.println(e);
		}
		fileInputStream = null;
	}

	@Test
	public void testCommandLineOptions() {
		String args1[] = {"-X"};
		String args2[] = {"-o", "ignore", " this "};
		String args3[] = {"no", "options"};

		ArrayList<Integer> results = new ArrayList<Integer>();
		results.add(1);
		results.add(2); 
		assertEquals(1, Main.parseArgs(args1), "Command line options check. ");
		assertEquals(2, Main.parseArgs(args2), "Command line options check. ");
		assertTrue(results.contains(Main.parseArgs(args3)), "No command line options check. ");
	}

	@Test
	public void testPlayerNameInput() {
		setInput("  John Doe \n Wick !@!~\n\n");
		String result = UI.getName('X');
		assertEquals("John Doe", result, "Player name input check. ");

		resetOutput();
		setInput("John Doe\n  \t\nJames\n~\n");
		result = UI.getName('X');
		assertEquals("James", result, "Player name input check. ");
		String outputText = byteArrayOutputStream.toString();
		String expectedOutput = "Player X\'s name cannot be blank or the same as another player's name. ";
		assertTrue(outputText.contains(expectedOutput), "Error message check. ");
	}

	@Test
	public void testPlayer() {
		PlayerInterface player = new Player("Adam", 1);
		assertEquals("Adam", player.getName(), "Player name check. ");
		assertEquals(1, player.getPlayerNumber(), "Player number check. ");
		assertEquals('X', player.getPlayerState(), "Player character check. ");

		player = new Player("Mary", 2);
		assertEquals("Mary", player.getName(), "Player name check. ");
		assertEquals('O', player.getPlayerState(), "Player character check. ");
		assertEquals(0, player.getMoveNum(), "Player move number check. ");
	}

	@Test
	public void testGetPiece() {
		PlayerInterface player = new Player("John", 0);

		setInput(" X \n");
		PieceInterface piece = new Piece(UI.getPiece(player));
		assertEquals("X", piece.getShape(), "Piece shape check. ");
		assertEquals(5, piece.getSize(), "Piece size check. ");

		resetOutput();
		setInput(" C \nn\n");
		piece = new Piece(UI.getPiece(player));
		assertEquals("N", piece.getShape(), "Piece shape check. ");
		assertTrue(Arrays.deepEquals(new int[][] {{-1, 0, 1 ,2}, {4, 3, -1, -1}}, piece.getOrientation()), "Piece orientation check. ");
		String outputText = byteArrayOutputStream.toString();
		String expectedOutput = "C is unavailable or not a valid piece. ";
		assertTrue(outputText.contains(expectedOutput), "Error message check. ");
	}

	@Test
	public void testRotatePiece() {
		PieceInterface piece = new Piece("T4");
		assertTrue(Arrays.deepEquals(new int[][] {{-1, 1, -1}, {3, 0, 2}}, piece.getOrientation()), "Piece orientation check. ");
		piece.rotate();
		assertTrue(Arrays.deepEquals(new int[][] {{3, -1}, {0, 1}, {2, -1}}, piece.getOrientation()), "Piece orientation check. ");

		piece = new Piece("F");
		assertTrue(Arrays.deepEquals(new int[][] {{-1, 1, 2}, {4, 0, -1}, {-1, 3, -1}}, piece.getOrientation()), "Piece orientation check. ");
		piece.rotate();
		piece.rotate();
		assertTrue(Arrays.deepEquals(new int[][] {{-1, 3, -1}, {-1, 0, 4}, {2, 1, -1}}, piece.getOrientation()), "Piece orientation check. ");
	}

	@Test
	public void testFlipPiece() {
		PieceInterface piece = new Piece("Y");
		assertTrue(Arrays.deepEquals(new int[][] {{-1, 1, -1, -1}, {4, 0, 2, 3}}, piece.getOrientation()), "Piece orientation check. ");
		piece.flip();
		assertTrue(Arrays.deepEquals(new int[][] {{-1, -1, 1, -1}, {3, 2, 0, 4}}, piece.getOrientation()), "Piece orientation check. ");

		piece = new Piece("F");
		assertTrue(Arrays.deepEquals(new int[][] {{-1, 1, 2}, {4, 0, -1}, {-1, 3, -1}}, piece.getOrientation()), "Piece orientation check. ");
		piece.flip();
		assertTrue(Arrays.deepEquals(new int[][] {{2, 1, -1}, {-1, 0, 4}, {-1, 3, -1}}, piece.getOrientation()), "Piece orientation check. ");
	}

	@Test
	public void testPrintPiece() {
		PlayerInterface player = new Player("John", 0);

		PieceInterface piece = new Piece("W");
		UI.printPiece(player, piece);
		String outputText = byteArrayOutputStream.toString();
		String expectedOutput = "  # # \n" + 
								"# *   \n" + 
								"#     \n";
		assertTrue(outputText.contains(expectedOutput), "Piece output check. ");

		piece = new Piece("L4");
		UI.printPiece(player, piece);
		outputText = byteArrayOutputStream.toString();
		expectedOutput = "#   \n" + 
				 		 "#   \n" + 
						 "* # \n";
		assertTrue(outputText.contains(expectedOutput), "Piece output check. ");
	}

	@Test
	public void testManipulatePiece() {
		PlayerInterface player = new Player("John", 0);

		setInput("d\n p\nr f n abc R p\n");
		PieceInterface piece = new Piece(UI.getPiece(player));
		UI.manipulatePiece(player, piece);
		UI.printPiece(player, piece);
		String outputText = byteArrayOutputStream.toString();
		String expectedOutput = "# * \n" + 
					 		    "# # \n" + 
							    "  # \n";
		assertTrue(outputText.contains(expectedOutput), "Piece manipulation & output check. ");

		setInput("d\n i5\nr F n abc t p\n");
		piece = new Piece("I3");
		UI.manipulatePiece(player, piece);
		assertTrue(Arrays.deepEquals(new int[][] {{2, 1, 0}}, piece.getOrientation()), "Piece manipulation & output check. ");
	}

	@Test
	public void testGetCoordinates() {
		setInput("\n15 2\n 3 -2\n 8 1\n\n 7 9\n");
		int coordinates[] = UI.getCoordinates();
		assertTrue(Arrays.equals(new int[] {12, 8}, coordinates), "Coordinates input check. ");

		resetOutput();
		setInput("18 02\n 300 -2\n 9 9\n");
		coordinates = UI.getCoordinates();
		assertTrue(Arrays.equals(new int[] {4, 9}, coordinates), "Coordinates input check. ");		
		String outputText = byteArrayOutputStream.toString();
		String expectedOutput = "x and y must be integers between 0 and 13: ";
		assertTrue(outputText.contains(expectedOutput), "Error message check. ");
	}

	@Test
	public void testEmptyBoard() {
		BoardInterface board = new Board();
		UI.printBoard(board);
		assertEquals(board.getSquareState(0, 0), '.', "Board character check. ");
		assertEquals(board.getSquareState(7, 2), '.', "Board character check. ");
		assertEquals(board.getSquareState(4, 4), 'x', "Board character check. ");
		assertEquals(board.getSquareState(9, 9), 'o', "Board character check. ");

		String outputText = byteArrayOutputStream.toString();
		String expectedOutput = "\nBLOKUS DUO\n\n" + 
								"13 . . . . . . . . . . . . . . \n" + 
								"12 . . . . . . . . . . . . . . \n" + 
								"11 . . . . . . . . . . . . . . \n" + 
								"10 . . . . . . . . . . . . . . \n" + 
								" 9 . . . . x . . . . . . . . . \n" + 
								" 8 . . . . . . . . . . . . . . \n" + 
								" 7 . . . . . . . . . . . . . . \n" + 
								" 6 . . . . . . . . . . . . . . \n" + 
								" 5 . . . . . . . . . . . . . . \n" + 
								" 4 . . . . . . . . . o . . . . \n" + 
								" 3 . . . . . . . . . . . . . . \n" + 
								" 2 . . . . . . . . . . . . . . \n" + 
								" 1 . . . . . . . . . . . . . . \n" + 
								" 0 . . . . . . . . . . . . . . \n" + 
								"   0 1 2 3 4 5 6 7 8 9 10111213\n\n\n";
		assertEquals(expectedOutput, outputText, "Empty board check. ");
	}

	@Test
	public void testUpdateBoard() {
		BoardInterface board = new Board();
		PlayerInterface player1 = new Player("John", 1);
		PlayerInterface player2 = new Player("Mary", 2);
		PieceInterface piece = new Piece("X");
		MoveInterface invalidMove = new Move(player1, piece, 9, 9);
		Exception e = assertThrows(InvalidMoveException.class, () -> board.updateBoard(invalidMove), "Invalid move check. ");
		assertNotNull(e.getMessage(), "Exception message check. ");
		UI.printBoard(board);
		String outputText = byteArrayOutputStream.toString();
		String expectedOutput = "\nBLOKUS DUO\n\n" + 
								"13 . . . . . . . . . . . . . . \n" + 
								"12 . . . . . . . . . . . . . . \n" + 
								"11 . . . . . . . . . . . . . . \n" + 
								"10 . . . . . . . . . . . . . . \n" + 
								" 9 . . . . x . . . . . . . . . \n" + 
								" 8 . . . . . . . . . . . . . . \n" + 
								" 7 . . . . . . . . . . . . . . \n" + 
								" 6 . . . . . . . . . . . . . . \n" + 
								" 5 . . . . . . . . . . . . . . \n" + 
								" 4 . . . . . . . . . o . . . . \n" + 
								" 3 . . . . . . . . . . . . . . \n" + 
								" 2 . . . . . . . . . . . . . . \n" + 
								" 1 . . . . . . . . . . . . . . \n" + 
								" 0 . . . . . . . . . . . . . . \n" + 
								"   0 1 2 3 4 5 6 7 8 9 10111213\n\n\n";
		assertEquals(expectedOutput, outputText, "Empty board check. ");

		resetOutput();
		MoveInterface latencyMove = new Move(player1, piece, 5, 4);
		assertTimeout(ofMillis(10), () -> board.updateBoard(latencyMove), "Update latency check. ");
		player1.updateHistory(latencyMove);
		UI.printBoard(board);
		outputText = byteArrayOutputStream.toString();
		expectedOutput = "\nBLOKUS DUO\n\n" + 
								"13 . . . . . . . . . . . . . . \n" + 
								"12 . . . . . . . . . . . . . . \n" + 
								"11 . . . . . . . . . . . . . . \n" + 
								"10 . . . . . . . . . . . . . . \n" + 
								" 9 . . . . X . . . . . . . . . \n" + 
								" 8 . . . X X X . . . . . . . . \n" + 
								" 7 . . . . X . . . . . . . . . \n" + 
								" 6 . . . . . . . . . . . . . . \n" + 
								" 5 . . . . . . . . . . . . . . \n" + 
								" 4 . . . . . . . . . o . . . . \n" + 
								" 3 . . . . . . . . . . . . . . \n" + 
								" 2 . . . . . . . . . . . . . . \n" + 
								" 1 . . . . . . . . . . . . . . \n" + 
								" 0 . . . . . . . . . . . . . . \n" + 
								"   0 1 2 3 4 5 6 7 8 9 10111213\n\n\n";
		assertEquals(expectedOutput, outputText, "Board update check. ");

		resetOutput();
		piece = new Piece("L4");
		piece.rotate();
		MoveInterface move = new Move(player2, piece, 9, 9);
		board.updateBoard(move);
		player2.updateHistory(move);
		UI.printBoard(board);
		outputText = byteArrayOutputStream.toString();
		expectedOutput = "\nBLOKUS DUO\n\n" + 
								"13 . . . . . . . . . . . . . . \n" + 
								"12 . . . . . . . . . . . . . . \n" + 
								"11 . . . . . . . . . . . . . . \n" + 
								"10 . . . . . . . . . . . . . . \n" + 
								" 9 . . . . X . . . . . . . . . \n" + 
								" 8 . . . X X X . . . . . . . . \n" + 
								" 7 . . . . X . . . . . . . . . \n" + 
								" 6 . . . . . . . . . . . . . . \n" + 
								" 5 . . . . . . . . . . . . . . \n" + 
								" 4 . . . . . . . . . O O O . . \n" + 
								" 3 . . . . . . . . . O . . . . \n" + 
								" 2 . . . . . . . . . . . . . . \n" + 
								" 1 . . . . . . . . . . . . . . \n" + 
								" 0 . . . . . . . . . . . . . . \n" + 
								"   0 1 2 3 4 5 6 7 8 9 10111213\n\n\n";
		assertEquals(expectedOutput, outputText, "Board update check. ");

		resetOutput();
		piece = new Piece("Z5");
		piece.flip();
		move = new Move(player2, piece, 12, 11);
		board.updateBoard(move);
		player2.updateHistory(move);
		UI.printBoard(board);
		outputText = byteArrayOutputStream.toString();
		expectedOutput = "\nBLOKUS DUO\n\n" + 
								"13 . . . . . . . . . . . . . . \n" + 
								"12 . . . . . . . . . . . . . . \n" + 
								"11 . . . . . . . . . . . . . . \n" + 
								"10 . . . . . . . . . . . . . . \n" + 
								" 9 . . . . X . . . . . . . . . \n" + 
								" 8 . . . X X X . . . . . . . . \n" + 
								" 7 . . . . X . . . . . . . . . \n" + 
								" 6 . . . . . . . . . . . . . . \n" + 
								" 5 . . . . . . . . . . . . . . \n" + 
								" 4 . . . . . . . . . O O O . . \n" + 
								" 3 . . . . . . . . . O . . . . \n" + 
								" 2 . . . . . . . . . . O . . . \n" + 
								" 1 . . . . . . . . . . O O O . \n" + 
								" 0 . . . . . . . . . . . . O . \n" + 
								"   0 1 2 3 4 5 6 7 8 9 10111213\n\n\n";
		assertEquals(expectedOutput, outputText, "Board update check. ");
	}

	@Test
	public void testGame() {
		setInputFromFile("test_files/sample1.txt");
		String args[] = {"-X"};
		assertTimeout(ofMillis(2000), () -> Main.main(args), "Game latency check. ");
		String outputText = byteArrayOutputStream.toString();
		String expectedOutput1 = "Player John (X) goes first! \n";
		String expectedOutput2 = "\nBLOKUS DUO\n\n" + 
								"13 . . . . . . . . . . . . . . \n" + 
								"12 . . . . . . . . . . . . . . \n" + 
								"11 . . . . . . . . . . . . . . \n" + 
								"10 . . . . . . . . . . . . . . \n" + 
								" 9 . . . . x . . . . . . . . . \n" + 
								" 8 . . . . . . . . . . . . . . \n" + 
								" 7 . . . . . . . . . . . . . . \n" + 
								" 6 . . . . . . . . . . . . . . \n" + 
								" 5 . . . . . . . . . . . . . . \n" + 
								" 4 . . . . . . . . . o . . . . \n" + 
								" 3 . . . . . . . . . . . . . . \n" + 
								" 2 . . . . . . . . . . . . . . \n" + 
								" 1 . . . . . . . . . . . . . . \n" + 
								" 0 . . . . . . . . . . . . . . \n" + 
								"   0 1 2 3 4 5 6 7 8 9 10111213\n\n\n";
		String expectedOutput3 = "\nBLOKUS DUO\n\n" + 
								"13 X X O O O O X O . . O O . O \n" + 
								"12 X X O X X X X O X O O X O O \n" + 
								"11 O O X . O O O X X X O X O . \n" + 
								"10 O X X X O O X O O O X O X O \n" + 
								" 9 O O X O X X X O X X X O X O \n" + 
								" 8 X . O O . . X O X O . O X O \n" + 
								" 7 X O O . X X O . O O . O X . \n" + 
								" 6 X . X X X O O O . O . O X . \n" + 
								" 5 X O O O O X O . O X X X O O \n" + 
								" 4 O X O X X X . X O O O X O O \n" + 
								" 3 O X X O O O X X . . O X . . \n" + 
								" 2 O . X X . O O X X O X O X X \n" + 
								" 1 O X O O O X X O . O . O O X \n" + 
								" 0 X X X X O X X X O O O . X X \n" + 
								"   0 1 2 3 4 5 6 7 8 9 10111213\n\n\n";
		String expectedOutput4 = "Player John (X) gamepieces: I3 V3 Z4";
		String expectedOutput5 = "Player Mary (O) gamepieces:";
		String expectedOutput6 = "GAME OVER!";
		assertTrue(outputText.contains(expectedOutput1), "Game output check. ");
		assertTrue(outputText.contains(expectedOutput2), "Game output check. ");
		assertTrue(outputText.contains(expectedOutput3), "Game output check. ");
		assertTrue(outputText.contains(expectedOutput4), "Game output check. ");
		assertTrue(outputText.contains(expectedOutput5), "Game output check. ");
		assertTrue(outputText.contains(expectedOutput6), "Game output check. ");
	}

}
