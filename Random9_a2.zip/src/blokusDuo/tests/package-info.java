/**
 * Random9
 * 20201034
 */
/**
 * @author agbod
 * JUnit tests
 */
package tests;