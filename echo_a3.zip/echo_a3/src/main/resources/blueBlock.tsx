<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="blueBlock" tilewidth="32" tileheight="32" tilecount="484" columns="22">
 <image source="blueBlock.svg" width="708" height="708"/>
</tileset>
