/**
 * Random9
 * 20201034
 */
package gameLogic.interfaces;

/**
 * @author agbod
 *
 */
public interface CoordinateInterface {
	
	int getRow();

	int getColumn();

}
