/**
 * Random9
 * 20201034
 */
/**
 * @author agbod
 * Model in MVC pattern
 */
package gameLogic;