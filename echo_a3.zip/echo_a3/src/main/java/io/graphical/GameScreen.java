/**
 * Random9
 * 20201034
 */
package io.graphical;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.ScreenUtils;

public class GameScreen extends ScreenAdapter {

    BlokusDuoGame game;
    Stage stage;
    Skin skin;
    SpriteBatch batch;
    Sprite block;

    public GameScreen(BlokusDuoGame game) {
        this.game = game;
        this.stage = game.stage;
        this.skin = game.skin;
        this.batch = new SpriteBatch();
        this.block = new Sprite(new Texture(Gdx.files.internal("blocks/aquaBlock.png")), 64, 64);
    }

    @Override
    public void render(float delta) {
        super.render(delta);
        ScreenUtils.clear(Color.YELLOW);

        batch.begin();
        block.draw(batch);
        batch.end();    

        stage.act(delta);
        stage.draw();
    }

}
