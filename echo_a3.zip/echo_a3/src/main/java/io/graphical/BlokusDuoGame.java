/**
 * Random9
 * 20201034
 */
package io.graphical;

import java.io.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import controller.*;
import gameLogic.*;
import gameLogic.interfaces.*;
import io.interfaces.*;

/**
 * @author agbod
 *
 */
public class BlokusDuoGame extends Game {

    final float DEFAULT_PADDING = 10;

    private GameController gameController;
    PrintStream ioStream;

    SpriteBatch batch;
    OrthographicCamera camera;
    Stage stage;
    Skin skin;
    Viewport viewport;

    private Screen setupScreen;
    private Screen gameScreen;

    public BlokusDuoGame(GameController gameController, UI ui) {
        GUI gui = (GUI)ui;
        this.gameController = gameController;

        gui.setGame(this); // for posting runnables into libGDX game loop
        this.ioStream = new PrintStream(gui.getPipedOutputStream());  // for sending text to control
    }

    @Override
    public void create() {
        this.camera = new OrthographicCamera();
        this.camera.setToOrtho(false);
        this.viewport = new ScreenViewport(camera);
        // this.viewport = new StretchViewport(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), camera);
        this.stage = new Stage(viewport); //, batch);
        this.skin = new Skin(Gdx.files.internal("uiskin.json"));
        Gdx.graphics.setTitle("Blokus Duo");
        Gdx.input.setInputProcessor(stage);

        this.setupScreen = new SetupScreen(this);
        this.gameScreen = new GameScreen(this);
        activateSetupScreen();
    }

    @Override
    public void render() {
        super.render(); // important!
    }

    public void activateSetupScreen() {
        setScreen(this.setupScreen);
    }

    public void postRunnable(Runnable r) {
        Gdx.app.postRunnable(r);
    }

    public void showMessage(String title, String message) {
        Dialog dialog = new Dialog(title, this.skin);
        dialog.text(message);
        dialog.button("OK");
        dialog.getContentTable().pad(DEFAULT_PADDING);
        dialog.getButtonTable().pad(DEFAULT_PADDING);
        dialog.show(this.stage);
    }

    @Override
    public void dispose() {
        super.dispose();
        if (this.batch != null) {
            this.batch.dispose();
        }
        if (this.stage != null) {
            this.stage.dispose();
        }
        if (this.skin != null) {
            this.skin.dispose();
        }
        if (this.gameController != null) {
            this.gameController.stop();
        }
    }

}