/**
 * Random9
 * 20201034
 */
package io.graphical;

import java.io.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import gameLogic.*;
import gameLogic.interfaces.*;
import io.interfaces.*;
import io.text.*;

/**
 * @author agbod
 *
 */
public class GUI implements UI {

	/**
	 * Utility class for graphical IO
	 */
	private PipedOutputStream pipedOutputStream;
	private PipedInputStream pipedInputStream;
	private Scanner scanner;
	private ArrayList<String> playerNames = new ArrayList<String>();
	private BlokusDuoGame game;
	private TextUI textUI = new TextUI();
	

	public GUI() throws IOException {
		pipedOutputStream = new PipedOutputStream();
		pipedInputStream = new PipedInputStream(pipedOutputStream);
		initScanner();
	}

    void setGame(BlokusDuoGame game) {
        this.game = game;
    }

    PipedOutputStream getPipedOutputStream() {
        return pipedOutputStream;
    }

	private void initScanner() {
		scanner = new Scanner(pipedInputStream);
	}
	
	@Override
	public PlayerInterface[] getPlayers(int startingPlayer) {
		String[] playerNames = getNames();
		String player1Name = playerNames[0];
		String player2Name = playerNames[1];
		PlayerInterface player1, player2;
		if (startingPlayer == 1) { //Initialise players
			player1 = new Player(player1Name, 1);
			player2 = new Player(player2Name, 2);
		} else {
			player2 = new Player(player1Name, 1);
			player1 = new Player(player2Name, 2);
		}
		return new PlayerInterface[]{player1, player2};
	}

	private String[] getNames() {
		String player1Name = scanner.nextLine().trim();
		String player2Name = scanner.nextLine().trim();
		while (player1Name.isEmpty() || player2Name.isEmpty() || player1Name == player2Name) {
			if (player1Name.isEmpty()) {
				showMessage("Error! ", "Player 1\'s name cannot be blank. ");
			} else if (player2Name.isEmpty()) {
				showMessage("Error! ", "Player 2\'s name cannot be blank. ");
			} else {
				showMessage("Error! ", "Both players cannot have the same name. ");
			}
			player1Name = scanner.nextLine().trim();
			player2Name = scanner.nextLine().trim();
		}
		return new String[]{player1Name, player2Name};
	}

	@Override
	public MoveInterface getMove(PlayerInterface player) {
		return textUI.getMove(player);
	}

	@Override
	public void displayFirstPlayer(PlayerInterface player) {
		showMessage("", player.getName() + " goes first. ");
	}

	@Override
	public void displayBoard(BoardInterface board) {
		textUI.displayBoard(board);
	}

	@Override
	public void displayPieces(PlayerInterface player) {
		textUI.displayPieces(player);
	}
	
	@Override
	public void displayInvalidMove() { //Notify player that move selected was invalid
		textUI.displayInvalidMove();
	}

	@Override
	public void displayPlayerTurn(PlayerInterface player) {
		textUI.displayPlayerTurn(player);
	}

	@Override
	public void displayNoValidMove(PlayerInterface player) {
		textUI.displayNoValidMove(player);
	}

	@Override
	public void displayResults(PlayerInterface player1, PlayerInterface player2) {
		textUI.displayResults(player1, player2);
	}

	@Override
	public void hint(List<MoveInterface> moves) {
		textUI.hint(moves);
	}

	@Override
	public void closeScanner() {
		scanner.close();
	}

	private void showMessage(String title, String message) {
        game.postRunnable(new Runnable() {
            @Override
            public void run() {
                game.showMessage(title, message);
            }
        });
   	}

}
