/**
 * Random9
 * 20201034
 */
package tests;

import static org.junit.jupiter.api.Assertions.*;

import static java.time.Duration.ofMillis;

import org.junit.jupiter.api.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;

import controller.Main;
import gameLogic.*;
import gameLogic.interfaces.*;
import io.text.*;

class BlokusDuoTests {
    @Test
    public void testCommandLineOptions() {
        String args1[] = {"-X"};
        String args2[] = {"-o", "-gui", "ignore", " this "};
        String args3[] = {"no", "options"};

        ArrayList<Integer> results = new ArrayList<Integer>();
        results.add(1);
        results.add(2); 
        
        Main.parseArgs(args1);
        assertEquals(1, Main.firstPlayer, "Command line options check. ");
        assertFalse(Main.useGUI, "Command line options check. ");
        Main.parseArgs(args2);
        assertEquals(2, Main.firstPlayer, "Command line options check. ");
        assertTrue(Main.useGUI, "Command line options check. ");
        Main.parseArgs(args3);
        assertTrue(results.contains(Main.firstPlayer), "No command line options check. ");
        assertFalse(Main.useGUI, "Command line options check. ");
    }

    @Test
    public void testPlayer() {
        PlayerInterface player = new Player("Adam", 1);
        assertEquals("Adam", player.getName(), "Player name check. ");
        assertEquals(1, player.getPlayerNumber(), "Player number check. ");

        player = new Player("Mary", 2);
        assertEquals("Mary", player.getName(), "Player name check. ");
        assertEquals(0, player.getMoveNum(), "Player move number check. ");
    }

    @Test
    public void testRotatePiece() {
        PieceInterface piece = new Piece("T4");
        assertTrue(Arrays.deepEquals(new int[][] {{-1, 1, -1}, {3, 0, 2}}, piece.getOrientation()), "Piece orientation check. ");
        piece.rotate();
        assertTrue(Arrays.deepEquals(new int[][] {{3, -1}, {0, 1}, {2, -1}}, piece.getOrientation()), "Piece orientation check. ");

        piece = new Piece("F");
        assertTrue(Arrays.deepEquals(new int[][] {{-1, 1, 2}, {4, 0, -1}, {-1, 3, -1}}, piece.getOrientation()), "Piece orientation check. ");
        piece.rotate();
        piece.rotate();
        assertTrue(Arrays.deepEquals(new int[][] {{-1, 3, -1}, {-1, 0, 4}, {2, 1, -1}}, piece.getOrientation()), "Piece orientation check. ");
    }

    @Test
    public void testFlipPiece() {
        PieceInterface piece = new Piece("Y");
        assertTrue(Arrays.deepEquals(new int[][] {{-1, 1, -1, -1}, {4, 0, 2, 3}}, piece.getOrientation()), "Piece orientation check. ");
        piece.flip();
        assertTrue(Arrays.deepEquals(new int[][] {{-1, -1, 1, -1}, {3, 2, 0, 4}}, piece.getOrientation()), "Piece orientation check. ");

        piece = new Piece("F");
        assertTrue(Arrays.deepEquals(new int[][] {{-1, 1, 2}, {4, 0, -1}, {-1, 3, -1}}, piece.getOrientation()), "Piece orientation check. ");
        piece.flip();
        assertTrue(Arrays.deepEquals(new int[][] {{2, 1, -1}, {-1, 0, 4}, {-1, 3, -1}}, piece.getOrientation()), "Piece orientation check. ");
    }

    @Test
    public void testCoordinate() {
        CoordinateInterface coordinate = new Coordinate(7, 13);
        assertEquals(7, coordinate.getRow(), "Coordinate row check. ");
        assertEquals(13, coordinate.getColumn(), "Coordinate column check. ");

        coordinate = new Coordinate(9, 1);
        assertEquals(9, coordinate.getRow(), "Coordinate row check. ");
        assertEquals(1, coordinate.getColumn(), "Coordinate column check. ");
    }

    @Test
    public void testMove() {
        PlayerInterface player = new Player("Adam", 1);
        PieceInterface piece = new Piece("X");
        CoordinateInterface coordinate = new Coordinate(4, 7);
        MoveInterface move = new Move(player, piece, coordinate);
        assertEquals(player, move.getPlayer(), "Move player check. ");
        assertTrue(Arrays.deepEquals(piece.getOrientation(), move.getPiece().getOrientation()), "Move piece check. ");
        assertEquals(coordinate, move.getCoordinate(), "Move coordinate check. ");
    }

    @Test
    public void testEmptyBoard() {
        BoardInterface board = new Board();
        assertTrue(board.getSquare(4, 4).isStartingSquare(1), "Empty board check. ");
        assertTrue(board.getSquare(9, 9).isStartingSquare(2), "Empty board check. ");
        for (int i = 0; i < Board.BOARD_SIZE; i++) {
            for (int j = 0; j < Board.BOARD_SIZE; j++) {
                if ((i != 4 && j != 4) && (i != 9 && j != 9)) {
                    assertTrue(board.getSquare(i, j).isEmpty(), "Empty board check. ");
                }
            }
        }
    }

    @Test
    public void testUpdateBoard() {
        BoardInterface board = new Board();
        PlayerInterface player1 = new Player("John", 1);
        PlayerInterface player2 = new Player("Mary", 2);
        PieceInterface piece = new Piece("X");
        MoveInterface invalidMove = new Move(player1, piece, new Coordinate(9, 9));
        Exception e = assertThrows(InvalidMoveException.class, () -> board.updateBoard(invalidMove), "Invalid move check. ");
        assertNotNull(e.getMessage(), "Exception message check. ");

        assertTrue(board.getSquare(4, 4).isStartingSquare(1), "Empty board check. ");
        assertTrue(board.getSquare(9, 9).isStartingSquare(2), "Empty board check. ");
        for (int i = 0; i < Board.BOARD_SIZE; i++) {
            for (int j = 0; j < Board.BOARD_SIZE; j++) {
                if ((i != 4 && j != 4) && (i != 9 && j != 9)) {
                    assertTrue(board.getSquare(i, j).isEmpty(), "Empty board check. ");
                }
            }
        }

        MoveInterface latencyMove = new Move(player1, piece, new Coordinate(5, 4));
        assertTimeout(ofMillis(10), () -> board.updateBoard(latencyMove), "Update latency check. ");
        player1.updateHistory(latencyMove);
        assertTrue(board.getSquare(4, 4).isOccupied(1), "Occupied square check. ");
        assertTrue(board.getSquare(5, 3).isOccupied(1), "Occupied square check. ");
        assertTrue(board.getSquare(5, 4).isOccupied(1), "Occupied square check. ");
        assertTrue(board.getSquare(5, 5).isOccupied(1), "Occupied square check. ");
        assertTrue(board.getSquare(6, 4).isOccupied(1), "Occupied square check. ");

        piece = new Piece("L4");
        piece.rotate();
        MoveInterface move = new Move(player2, piece, new Coordinate(9, 9));
        board.updateBoard(move);
        player2.updateHistory(move);
        assertTrue(board.getSquare(9, 9).isOccupied(2), "Occupied square check. ");
        assertTrue(board.getSquare(9, 10).isOccupied(2), "Occupied square check. ");
        assertTrue(board.getSquare(9, 11).isOccupied(2), "Occupied square check. ");
        assertTrue(board.getSquare(10, 9).isOccupied(2), "Occupied square check. ");

        piece = new Piece("Z5");
        piece.flip();
        move = new Move(player2, piece, new Coordinate(12, 11));
        board.updateBoard(move);
        player2.updateHistory(move);
        assertTrue(board.getSquare(11, 10).isOccupied(2), "Occupied square check. ");
        assertTrue(board.getSquare(12, 10).isOccupied(2), "Occupied square check. ");
        assertTrue(board.getSquare(12, 11).isOccupied(2), "Occupied square check. ");
        assertTrue(board.getSquare(12, 12).isOccupied(2), "Occupied square check. ");
        assertTrue(board.getSquare(13, 12).isOccupied(2), "Occupied square check. ");
    }

}
