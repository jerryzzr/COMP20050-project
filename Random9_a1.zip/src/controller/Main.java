/**
 * Random9
 * 20201034
 */
package controller;

import textIO.UI;

/**
 * @author agbod
 *
 */
public class Main {

	/**
	 * contains main function to start a game
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		UI.initScanner();
		Game.run();
		UI.closeScanner();
	}

}
