/**
 * Random9
 * 20201034
 */
package controller;

import gameLogic.Board;
import gameLogic.InvalidMoveException;
import gameLogic.Move;
import gameLogic.Piece;
import gameLogic.Player;
import textIO.UI;

/**
 * @author agbod
 *
 */
public class Game {

	/**
	 * 
	 */
	public static void run() { //Run a full game from start to finish
		Board board = new Board(); //Initialise board and players
		Player player1 = new Player(UI.getName(1), Player.Player1Default);
		Player player2 = new Player(UI.getName(2), Player.Player2Default);
		Move move;
		
		move = getStartingMove(player1, 4); //Play first moves
		board.updateBoard(move);
		player1.updateHistory(move);
		UI.printBoard(board);
		
		move = getStartingMove(player2, 9);
		board.updateBoard(move);
		player2.updateHistory(move);
		UI.printBoard(board);
		
		Boolean player1HasMove = board.hasValidMove(player1);
		Boolean player2HasMove = board.hasValidMove(player2);
		
		while (player1HasMove || player2HasMove) { //Play until neither player can make a move
			boolean completedMove;
			if (player1HasMove) {
				try {
					move = getMove(player1);
					board.updateBoard(move);
					player1.updateHistory(move);
					UI.printBoard(board);
					completedMove = true;
				} catch (InvalidMoveException e) {
					completedMove = false;
				}
				
				while (!completedMove) {
					UI.printInvalidMove();
					try {
						move = getMove(player1);
						board.updateBoard(move);
						player1.updateHistory(move);
						UI.printBoard(board);
						completedMove = true;
					} catch (InvalidMoveException e) {
						completedMove = false;
					}
				}
			}
			
			if (player2HasMove) {
				try {
					move = getMove(player2);
					board.updateBoard(move);
					player2.updateHistory(move);
					UI.printBoard(board);
					completedMove = true;
				} catch (InvalidMoveException e) {
					completedMove = false;
				}
				
				while (!completedMove) {
					UI.printInvalidMove();
					try {
						move = getMove(player2);
						board.updateBoard(move);
						player2.updateHistory(move);
						UI.printBoard(board);
						completedMove = true;
					} catch (InvalidMoveException e) {
						completedMove = false;
					}
				}
			}
		}
		
		UI.printResults(player1, player2);
	}
	
	private static Move getStartingMove(Player player, int pos) { //Get a move with default starting positions
		UI.printPieces(player);
		Piece piece = UI.getPiece(player);
		if (piece.getSize() != 1) {
			UI.changeReferencePoint(piece);
			UI.rotatePiece(piece);
		}
		Move move = new Move(player, piece, pos, pos);
		return move;
	}
	
	private static Move getMove(Player player) { //Get a regular move
		UI.printPieces(player);
		Piece piece = UI.getPiece(player);
		if (piece.getSize() != 1) {
			UI.changeReferencePoint(piece);
			UI.rotatePiece(piece);
		}
		int row = UI.getRow();
		int column = UI.getColumn();
		Move move = new Move(player, piece, row, column);
		return move;
	}

}
