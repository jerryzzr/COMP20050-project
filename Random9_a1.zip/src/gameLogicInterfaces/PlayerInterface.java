/**
 * Random9
 * 20201034
 */
package gameLogicInterfaces;

import java.util.ArrayList;
import gameLogic.Move;
import gameLogic.Piece;

/**
 * @author agbod
 *
 */
public interface PlayerInterface {
	
	String getName();
	
	char getPlayerState();
	
	int getScore();
	
	ArrayList<Piece> getPieces(); //Should return list of all available pieces
	
	void updateHistory(Move move); //Add a move to the players history
	
	int getMoveNum();
	
}
