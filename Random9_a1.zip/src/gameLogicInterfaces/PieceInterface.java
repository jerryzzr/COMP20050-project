/**
 * Random9
 * 20201034
 */
package gameLogicInterfaces;

/**
 * @author agbod
 *
 */
public interface PieceInterface {
	
	String getShape();
	
	int getSize();
	
	void rotate90Right(); //Rotate piece clockwise
	
	void rotate90Left(); //Rotate piece anti-clockwise

	int getReferencePoint();
	
	void setReferencePoint(int referencePoint);
	
	int[][] getOrientation();
	
}
