/**
 * Random9
 * 20201034
 */
package gameLogicInterfaces;

import gameLogic.Move;
import gameLogic.Player;

/**
 * @author agbod
 *
 */
public interface BoardInterface {
	
	final static int BOARD_SIZE = 14;
		
	char getSquareState(int row, int column); //Get character of a board square
		
	void updateBoard(Move move); //Update the board with a given move
	
	boolean hasValidMove(Player player); //Check that a player has a valid move available
	
}
