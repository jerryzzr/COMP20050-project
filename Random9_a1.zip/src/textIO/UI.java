/**
 * Random9
 * 20201034
 */
package textIO;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import gameLogic.Board;
import gameLogic.Piece;
import gameLogic.Player;

/**
 * @author agbod
 *
 */
public class UI {

	/**
	 * Utility class for console IO
	 */
	private static Scanner scanner;
	private static ArrayList<String> playerNames = new ArrayList<String>();
	
	public static void initScanner() {
		scanner = new Scanner(System.in);
	}
	
	public static void printBoard(Board board) {
		for (int i = 0; i < Board.BOARD_SIZE; i++) {
			int row = Board.BOARD_SIZE - (i + 1);
			if (row < 10)
				System.out.print(" " + row + " ");
			else
				System.out.print(row + " ");
			for (int j = 0; j < Board.BOARD_SIZE; j++) {
				System.out.print(board.getSquareState(i, j) + " ");
			}
			System.out.println();
		}
		System.out.println("   0 1 2 3 4 5 6 7 8 9 10111213");
		System.out.println();
		System.out.println();
	}

	private static void printPiece(Piece piece) {
		System.out.println(piece.getShape() + ": ");
		int orientation[][] = piece.getOrientation();
		for (int i = 0; i < orientation.length; i++) {
			for (int j = 0; j < orientation[0].length; j++) {
				if (orientation[i][j] == piece.getReferencePoint()) {
					System.out.print("* ");
				} else if (orientation[i][j] >= 0) {
					System.out.print("# ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("\'*\' is the reference point of the piece. ");
		System.out.println();
	}
	
	private static void printPieceNumbers(Piece piece) { //Print piece as numbers unique to block components of the piece
		System.out.println(piece.getShape() + ": ");
		int orientation[][] = piece.getOrientation();
		for (int i = 0; i < orientation.length; i++) {
			for (int j = 0; j < orientation[0].length; j++) {
				if (orientation[i][j] >= 0) {
					System.out.print(orientation[i][j] + " ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("The reference point of the piece is " + piece.getReferencePoint());
		System.out.println();
	}

	public static void printPieces(Player player) {
		System.out.print("Player " + player.getName());
		System.out.print(" (" + player.getPlayerState() + ") gamepieces:");
		for (Piece pieces: player.getPieces()) {
			System.out.print(" " + pieces.getShape());
		}
		System.out.println();
		System.out.println();
	}
	
	public static void printInvalidMove() { //Notify player that move selected was invalid
		System.out.println("You have entered an invalid move. ");
		System.out.println();
	}

	public static void printResults(Player player1, Player player2) {
		int player1Score = player1.getScore();
		int player2Score = player2.getScore();
		if (player1Score > player2Score) {
			System.out.println(player1.getName() + " finished the game with " + player1Score + " points and " + player2.getName() + " finished the game with " + player2Score + " points. ");
			System.out.println(player1.getName() + " wins! ");
			System.out.println();
		} else if (player1Score < player2Score) {
			System.out.println(player1.getName() + " finished the game with " + player1Score + " points and " + player2.getName() + " finished the game with " + player2Score + " points. ");
			System.out.println(player2.getName() + " wins! ");
			System.out.println();
		} else {
			System.out.println("This game ended in a draw between " + player1.getName() + " and " + player2.getName() + ". ");
			System.out.println("Both players had " + player1Score + " points. ");
			System.out.println();
		}

	}

	public static String getName(int playerNum) {
		System.out.print("Enter the name of Player " + playerNum + ": ");
		String playerName = scanner.nextLine();
		while (playerName.trim().isEmpty() || playerName == null || playerNames.contains(playerName)) {
			System.out.println("Player " + playerNum + "\'s name cannot be blank or the same as another player's name. ");
			System.out.print("Enter the name of Player " + playerNum + ": ");
			playerName = scanner.nextLine();
		}
		playerNames.add(playerName);
		return playerName;
	}

	public static Piece getPiece(Player player) { //Get piece a player wants to play
		System.out.print("Enter the piece you want to play: ");
		String pieceName = scanner.nextLine();
		ArrayList<String> pieceNames = new ArrayList<String>();
		for (Piece p: player.getPieces()) {
			pieceNames.add(p.getShape());
		}
		while (!pieceNames.contains(pieceName.trim().toUpperCase())) {
			System.out.print(pieceName + " is unavailable or not a valid piece. ");
			System.out.print("Enter the piece you want to play: ");
			pieceName = scanner.nextLine();
		}
		return new Piece(Piece.Shape.valueOf(pieceName.toUpperCase()));
	}
	
	public static void changeReferencePoint(Piece piece) { //Change the block on a piece that is referenced to place it on the board. Useful for first move
		printPieceNumbers(piece);
		System.out.print("Enter a number between 0 and " + (piece.getSize() - 1) + " to change the reference point to that number. ");
		System.out.print("Enter anything else to keep it the same. ");
		int referencePoint = -1;
		try {
			referencePoint = scanner.nextInt();
			scanner.nextLine();
		} catch (InputMismatchException e) {
			referencePoint = piece.getReferencePoint();
			scanner.nextLine();
		}
		if (referencePoint >= 0 && referencePoint <= piece.getSize() - 1 && referencePoint != piece.getReferencePoint()) {
			piece.setReferencePoint(referencePoint);
			System.out.println("The reference point is now " + referencePoint + ". ");
		} else {
			System.out.println("The reference point will remain as " + referencePoint + ". ");
		}
		System.out.println();
	}

	public static void rotatePiece(Piece piece) { //Rotate the piece
		System.out.println("Enter \'a\' to rotate the piece anti-clockwise or \'d\' to rotate clockwise. ");
		System.out.println("Enter anything else to stop rotating the piece and place it: ");
		String temp = scanner.nextLine();
		while (temp.trim().equalsIgnoreCase("a") || temp.trim().equalsIgnoreCase("d")) {
			if (temp.trim().equalsIgnoreCase("a")) {
				piece.rotate90Left();
				printPiece(piece);
				temp = scanner.nextLine();
			} else if (temp.trim().equalsIgnoreCase("d")) {
				piece.rotate90Right();
				printPiece(piece);
				temp = scanner.nextLine();				
			} else {
				temp = scanner.nextLine();
			}
		}			
	}
	
	public static int getRow() { //Get row to place a piece on
		System.out.print("Enter the row to place the piece: ");
		int row = -1;
		try {
			row = scanner.nextInt();
			scanner.nextLine();
		} catch (InputMismatchException e) {
			row = -1;
		}
		while (row < 0 || row > 13) {
			try {
				System.out.print("Enter a number between 0 and 13: ");
				row = scanner.nextInt();
				scanner.nextLine();
			} catch (InputMismatchException e) {
				row = -1;
			}
		}
		return (Board.BOARD_SIZE - 1) - row;
	}
	
	public static int getColumn() { //Get column to place a piece on
		System.out.print("Enter the column to place the piece: ");
		int column = -1;
		try {
			column = scanner.nextInt();
			scanner.nextLine();
		} catch (InputMismatchException e) {
			column = -1;
		}
		while (column < 0 || column > 13) {
			try {
				System.out.print("Enter a number between 0 and 13: ");
				column = scanner.nextInt();
				scanner.nextLine();
			} catch (InputMismatchException e) {
				column = -1;
			}
		}
		return column;
	}

	public static void closeScanner() {
		scanner.close();
	}

}
