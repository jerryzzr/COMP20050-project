/**
 * Random9
 * 20201034
 */
package gameLogic;

import gameLogicInterfaces.BoardInterface;

/**
 * @author agbod
 *
 */
public class Board implements BoardInterface {

	/**
	 * Class to represent the physical object of the board as a 2D-array of squares/states
	 */	
	static final char EmptyState = '.';
	static final char StartingPoint = '*';
	private char board[][] = new char[BOARD_SIZE][BOARD_SIZE];
	
	public Board() { //Initialise board
		for (int i = 0; i < Board.BOARD_SIZE; i++) {
			for (int j = 0; j < Board.BOARD_SIZE; j++) {
				this.board[i][j] = EmptyState;
			}
		}
		this.board[4][4] = StartingPoint;
		this.board[9][9] = StartingPoint;
	}

	@Override
	public char getSquareState(int row, int column) {
		return this.board[row][column];
	}
	
	@Override
	public void updateBoard(Move move) {
		if (isValidMove(move)) {
			int orientation[][] = move.getPiece().getOrientation();
			int pieceHeight = orientation.length;
			int pieceWidth = orientation[0].length;
			int referencePoint[] = getPieceReferencePoint(move.getPiece());
			int referenceRow = referencePoint[0];
			int referenceColumn = referencePoint[1];
			int row =  move.getRow();
			int column = move.getColumn();
			Player player = move.getPlayer();
			for (int i = 0; i < pieceHeight; i++) {
				for (int j = 0; j < pieceWidth; j++) {
					if (orientation[i][j] >= 0) {
						int boardRow = (i - referenceRow) + row;
						int boardColumn = (j - referenceColumn) + column;
						this.board[boardRow][boardColumn] = player.getPlayerState();
					}
				}
			}
		} else {
			throw new InvalidMoveException();
		}
	}
	
	private boolean isWithinBoundaryCheck(Move move) { //Check that piece will be placed within board
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		boolean check = row - referenceRow >= 0 && row + (pieceHeight - (referenceRow + 1)) <= 13 && column - referenceColumn >= 0 && column + (pieceWidth - (referenceColumn + 1)) <= 13;
		return check;
	}
	
	private boolean noOccupiedSquareCheck(Move move) { //Check that piece will not overlap other pieces
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		boolean check = true;
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] > 0) {
					int boardRow = (i - referenceRow) + row;
					int boardColumn = (j - referenceColumn) + column;
					if (this.board[boardRow][boardColumn] != EmptyState && this.board[boardRow][boardColumn] != StartingPoint) {
						check = false;
						break;
					}
				}
			}
			if (!check) {
				break;
			}
		}
		return check;
	}

	private boolean noAdjacentSquareCheck(Move move) { //Check that that there will be no adjacent piece of the same colour
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		Player player = move.getPlayer();
		boolean check = true;
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] >= 0) {
					int boardRow = (i - referenceRow) + row;
					int boardColumn = (j - referenceColumn) + column;
					if (boardRow - 1 >= 0 && this.board[boardRow - 1][boardColumn] == player.getPlayerState()) {
						check = false;
						break;
					}
					if (boardRow + 1 <= 13 && this.board[boardRow + 1][boardColumn] == player.getPlayerState()) {
						check = false;
						break;
					}
					if (boardColumn - 1 >= 0 && this.board[boardRow][boardColumn - 1] == player.getPlayerState()) {
						check = false;
						break;
					}
					if (boardColumn + 1 <= 13 && this.board[boardRow][boardColumn + 1] == player.getPlayerState()) {
						check = false;
						break;
					}
				}
			}
			if (!check) {
				break;
			}
		}
		return check;
	}

	private boolean hasCornerSquareCheck(Move move) { //Check that piece will be touching the corner of another piece of the same colour
		int orientation[][] = move.getPiece().getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = getPieceReferencePoint(move.getPiece());
		int referenceRow = referencePoint[0];
		int referenceColumn = referencePoint[1];
		int row =  move.getRow();
		int column = move.getColumn();
		Player player = move.getPlayer();
		boolean check = false;
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] >= 0) {
					int boardRow = (i - referenceRow) + row;
					int boardColumn = (j - referenceColumn) + column;
					if (boardRow - 1 >= 0 && boardColumn -1 >= 0 && this.board[boardRow - 1][boardColumn - 1] == player.getPlayerState()) {
						check = true;
						break;
					}
					if (boardRow - 1 >= 0 && boardColumn + 1 <= 13 && this.board[boardRow - 1][boardColumn + 1] == player.getPlayerState()) {
						check = true;
						break;
					}
					if (boardRow + 1 <= 13 && boardColumn - 1 >= 0 && this.board[boardRow + 1][boardColumn - 1] == player.getPlayerState()) {
						check = true;
						break;
					}
					if (boardRow + 1 <= 13 && boardColumn + 1 <= 13 && this.board[boardRow + 1][boardColumn + 1] == player.getPlayerState()) {
						check = true;
						break;
					}
				}
			}
			if (check) {
				break;
			}
		}
		return check;
	}

	private boolean isValidMove(Move move) { //Checks that all conditions are satisfied
		if (move.getPlayer().getMoveNum() == 0) { //Checks for first move when there is no other piece of the same colour on the board
			return isWithinBoundaryCheck(move) && noOccupiedSquareCheck(move) && noAdjacentSquareCheck(move);
		} else {
			return isWithinBoundaryCheck(move) && noOccupiedSquareCheck(move) && noAdjacentSquareCheck(move) && hasCornerSquareCheck(move);
		}
	}

	private int[] getPieceReferencePoint(Piece piece) { //Get the row and column of the reference point relative to the rest of the piece
		int orientation[][] = piece.getOrientation();
		int pieceHeight = orientation.length;
		int pieceWidth = orientation[0].length;
		int referencePoint[] = {-1, -1};
		for (int i = 0; i < pieceHeight; i++) {
			for (int j = 0; j < pieceWidth; j++) {
				if (orientation[i][j] == 0) {
					referencePoint[0] = i;
					referencePoint[1] = j;
					break;
				}
			}
			if (referencePoint[0] != -1 && referencePoint[1] != -1) {
				break;
			}
		}
		return referencePoint;
	}

	@Override
	public boolean hasValidMove(Player player) {
		boolean check = false;
		for (Piece piece: player.getPieces()) {
			for (int i = 0; i < Board.BOARD_SIZE; i++) {
				for (int j = 0; j < Board.BOARD_SIZE; j++) {
					Move move = new Move(player, piece, i, j);
					if (isValidMove(move)) {
						check = true;
						break;
					}
				}
				if (check) {
					break;
				}
			}
			if (check) {
				break;
			}
		}
		return check;
	}
	
}
