/**
 * Random9
 * 20201034
 */
package gameLogic;

import gameLogicInterfaces.PieceInterface;

/**
 * @author agbod
 *
 */
public class Piece implements PieceInterface {

	/**
	 * Class to represent physical object of a piece as a shape with a reference point and orientation
	 */
	public enum Shape { //Piece names and array-based representations
		I1(new int[][] {{0}}, 1), 
		I2(new int[][] {{0}, {1}}, 2), 
		I3(new int[][] {{0}, {1}, {2}}, 3), 
		I4(new int[][] {{0}, {1}, {2}, {3}}, 4), 
		I5(new int[][] {{0}, {1}, {2}, {3}, {4}}, 5), 
		V3(new int[][] {{1, -1}, {0, 2}}, 3), 
		L4(new int[][] {{2, -1}, {1, -1}, {0, 3}}, 4), 
		Z4(new int[][] {{-1, 1, 2}, {3, 0, -1}}, 4), 
		O4(new int[][] {{1, 2}, {0, 3}}, 4), 
		L5(new int[][] {{1, -1, -1, -1}, {0, 2, 3, 4}}, 5), 
		T5(new int[][] {{-1, 2, -1}, {-1, 1, -1}, {4, 0, 3}}, 5), 
		V5(new int[][] {{2, -1, -1}, {1, -1, -1}, {0, 3, 4}}, 5), 
		N(new int[][] {{-1, 0, 1 ,2}, {4, 3, -1, -1}}, 5), 
		Z5(new int[][] {{-1, -1, 2}, {3, 0, 1}, {4, -1, -1}}, 5), 
		T4(new int[][] {{-1, 1, -1}, {3, 0, 2}}, 4), 
		P(new int[][] {{0, 1}, {3, 2}, {4, -1}}, 5), 
		W(new int[][] {{-1, 1, 2}, {3, 0, -1}, {4, -1, -1}}, 5), 
		U(new int[][] {{1, 2}, {0, -1}, {3, 4}}, 5), 
		F(new int[][] {{-1, 1, 2}, {4, 0, -1}, {-1, 3, -1}}, 5), 
		X(new int[][] {{-1, 1, -1}, {4, 0, 2}, {-1, 3, -1}}, 5), 
		Y(new int[][] {{-1, 1, -1, -1}, {4, 0, 2, 3}}, 5);
		
		final int defaultOrientation[][];
		final int size;
		
		Shape(int defaultOrientation[][], int size) {
			this.defaultOrientation = defaultOrientation;
			this.size = size;
		}
	}
		
	final Shape shape;
	private int referencePoint;		
	private int orientation[][];

	public Piece(Shape shape) {
		this.shape = shape;
		this.referencePoint = 0;
		this.orientation = shape.defaultOrientation;
	}

	@Override
	public String getShape() {
		return this.shape.name();
	}	

	@Override
	public int getSize() {
		return this.shape.size;
	}

	@Override
	public void rotate90Right() {
		int rows = this.orientation.length;
		int columns = this.orientation[0].length;
		int temp[][] = new int[columns][rows];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				temp[j][i] = this.orientation[rows - (i + 1)][j];
			}
		}
		this.orientation = temp;
	}

	@Override
	public void rotate90Left() {
		int rows = this.orientation.length;
		int columns = this.orientation[0].length;
		int temp[][] = new int[columns][rows];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				temp[j][i] = this.orientation[i][columns - (j + 1)];
			}
		}
		this.orientation = temp;
	}

	@Override
	public int getReferencePoint() {
		return this.referencePoint;
	}

	@Override
	public void setReferencePoint(int referencePoint) {
		this.referencePoint = referencePoint;
	}

	@Override
	public int[][] getOrientation() {
		return this.orientation.clone();
	}

}
