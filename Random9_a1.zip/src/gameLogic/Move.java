/**
 * Random9
 * 20201034
 */
package gameLogic;

/**
 * @author agbod
 *
 */
public class Move {

	/**
	 * Helper class to represent abstract concept of a move and reduce length of method signatures
	 */
	private Player player;
	
	private Piece piece;
	
	private int row, column;
		
	public Move(Player player, Piece piece, int row, int column) {
		this.player = player;
		this.piece = piece;
		this.row = row;
		this.column = column;
	}

	/**
	 * @return the player
	 */
	public Player getPlayer() {
		return player;
	}

	/**
	 * @return the piece
	 */
	public Piece getPiece() {
		return piece;
	}

	/**
	 * @return the row
	 */
	public int getRow() {
		return row;
	}

	/**
	 * @return the column
	 */
	public int getColumn() {
		return column;
	}

}
