/**
 * Random9
 * 20201034
 */
package gameLogic;

import java.util.ArrayList;

import gameLogicInterfaces.PlayerInterface;

/**
 * @author agbod
 *
 */
public class Player implements PlayerInterface {

	/**
	 * Class to represent physical player as a name and a board state, as well as record their pieces and move history
	 */	
	public static final char Player1Default = 'X';
	public static final char Player2Default = 'O';
	
	private final String name;
	private final char state; //Player character
	private ArrayList<Piece> pieces = new ArrayList<Piece>();
	private ArrayList<Move> history = new ArrayList<Move>();
	private int moveNum;

	public Player(String name, char state) { //Initialise a player and give them the full set of pieces
		this.name = name;
		this.state = state;
		for (Piece.Shape shape: Piece.Shape.values()) {
			this.pieces.add(new Piece(shape));
		}
		moveNum = 0;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public char getPlayerState() {
		return this.state;
	}

	@Override
	public int getScore() {
		int sum;
		if (pieces.isEmpty()) {
			sum = 15;
			if (history.get(history.size() - 1).getPiece().getSize() == 1) {
				sum += 5;
			}
		} else {
			sum = 0;
			for (Piece piece: this.pieces) {
				sum -= piece.getSize();
			}
		}
		return sum;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Piece> getPieces() {
		return (ArrayList<Piece>)this.pieces.clone();
	}

	private void playPiece(Piece piece) { //Remove a piece from the players available pieces
		for (Piece p: pieces) {
			if (p.shape.equals(piece.shape)) {
				pieces.remove(p);
				break;
			}
		}
	}

	@Override
	public void updateHistory(Move move) {
		this.history.add(move);
		this.moveNum++;
		playPiece(move.getPiece());
	}

	@Override
	public int getMoveNum() {
		return this.moveNum;
	}

}
