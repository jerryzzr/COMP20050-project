/**
 * 
 */
/**
 * @author agbod
 *
 */
module blokusDuo {
}